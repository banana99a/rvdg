// This is a mock service that would normally interact with a payment gateway
// In a real application, this would connect to a payment processor API

interface CustomerInfo {
  name: string
  email: string
  cpf: string
}

interface TicketInfo {
  type: string
  price: string
}

interface PaymentIntent {
  id: string
  amount: string
  currency: string
  status: "pending" | "paid" | "failed" | "canceled"
  customerInfo: CustomerInfo
  ticketInfo: TicketInfo
  paymentCode: string
  pixCode: string
  createdAt: number
  updatedAt: number
  expiresAt: number
}

// In-memory database for payment intents
let paymentIntents: PaymentIntent[] = []

// Admin email for notifications
const ADMIN_EMAIL = "edilsonsgouveia00@gmail.com"

// PIX codes for each ticket type
const PIX_CODES = {
  "Ingresso Feminino":
    "00020126330014br.gov.bcb.pix011148370885896520400005303986540525.005802BR5924Edilson Dos Santos Gouve6008Brasilia62240520daqr1064735690745860630443F8",
  "Ingresso Masculino":
    "00020126330014br.gov.bcb.pix011148370885896520400005303986540540.005802BR5924Edilson Dos Santos Gouve6008Brasilia62240520daqr10647356907731836304C546",
  "Ingresso VIP":
    "00020126330014br.gov.bcb.pix011148370885896520400005303986540565.005802BR5924Edilson Dos Santos Gouve6008Brasilia62240520daqr10647356907895936304AD13",
}

// Add this function after the PIX_CODES declaration
function validatePixCodes() {
  console.log("Validating PIX codes...")
  for (const [type, code] of Object.entries(PIX_CODES)) {
    if (!code || typeof code !== "string" || code.length < 10) {
      console.error(`Invalid PIX code for ${type}: ${code}`)
    } else {
      console.log(`PIX code for ${type} is valid: ${code.substring(0, 20)}...`)
    }
  }
}

// Generate a random payment code
function generatePaymentCode(): string {
  const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
  let result = ""
  for (let i = 0; i < 10; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length))
  }
  return result
}

// Generate a random ID
function generateId(): string {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
}

// Create a new payment intent
export async function createPaymentIntent({
  customerInfo,
  ticketInfo,
}: {
  customerInfo: CustomerInfo
  ticketInfo: TicketInfo
}): Promise<PaymentIntent> {
  const now = Date.now()

  // Get the correct PIX code for the ticket type
  let pixCode = PIX_CODES[ticketInfo.type as keyof typeof PIX_CODES]
  if (!pixCode) {
    console.error(`PIX code not found for ticket type: ${ticketInfo.type}`)
    // Fallback to a default PIX code or generate a placeholder
    pixCode =
      "00020126330014br.gov.bcb.pix011148370885896520400005303986540525.005802BR5924Edilson Dos Santos Gouve6008Brasilia62240520daqr1064735690745860630443F8"
  }

  const paymentIntent: PaymentIntent = {
    id: generateId(),
    amount: ticketInfo.price,
    currency: "BRL",
    status: "pending",
    customerInfo,
    ticketInfo,
    paymentCode: generatePaymentCode(),
    pixCode,
    createdAt: now,
    updatedAt: now,
    expiresAt: now + 24 * 60 * 60 * 1000, // 24 hours from now
  }

  // In a real app, this would be a database insert
  paymentIntents.push(paymentIntent)

  // Send notification to admin about new payment intent
  await sendPaymentCreatedNotification(paymentIntent)

  return paymentIntent
}

// Get a payment intent by ID
export async function getPaymentIntent(id: string): Promise<PaymentIntent | null> {
  // In a real app, this would be a database query
  const paymentIntent = paymentIntents.find((p) => p.id === id)
  return paymentIntent || null
}

// Update a payment intent status
export async function updatePaymentIntentStatus(
  id: string,
  status: "pending" | "paid" | "failed" | "canceled",
): Promise<PaymentIntent | null> {
  // In a real app, this would be a database update
  const paymentIntentIndex = paymentIntents.findIndex((p) => p.id === id)

  if (paymentIntentIndex === -1) return null

  paymentIntents[paymentIntentIndex].status = status
  paymentIntents[paymentIntentIndex].updatedAt = Date.now()

  // If status changed to paid, notify admin
  if (status === "paid") {
    await sendPaymentConfirmedNotification(paymentIntents[paymentIntentIndex])
  }

  return paymentIntents[paymentIntentIndex]
}

// Confirm payment (mock function)
export async function confirmPayment(id: string): Promise<PaymentIntent | null> {
  // In a real app, this would check with the payment gateway
  // For this demo, we'll just update the status to "paid"
  return updatePaymentIntentStatus(id, "paid")
}

// Send notification to admin when a new payment is created
export async function sendPaymentCreatedNotification(payment: PaymentIntent): Promise<boolean> {
  // In a real app, this would send an actual email
  console.log(`Sending admin notification to ${ADMIN_EMAIL} for new payment intent:`)
  console.log(`- Payment ID: ${payment.id}`)
  console.log(`- Ticket: ${payment.ticketInfo.type} (R$ ${payment.amount})`)
  console.log(`- Customer: ${payment.customerInfo.name} (${payment.customerInfo.email})`)
  console.log(`- Status: ${payment.status}`)
  console.log(`- Created: ${new Date(payment.createdAt).toLocaleString()}`)

  // Simulate email sending delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  return true
}

// Send notification to admin when a payment is confirmed
export async function sendPaymentConfirmedNotification(payment: PaymentIntent): Promise<boolean> {
  // In a real app, this would send an actual email
  console.log(`Sending admin notification to ${ADMIN_EMAIL} for payment confirmation:`)
  console.log(`- Payment ID: ${payment.id}`)
  console.log(`- Ticket: ${payment.ticketInfo.type} (R$ ${payment.amount})`)
  console.log(`- Customer: ${payment.customerInfo.name} (${payment.customerInfo.email})`)
  console.log(`- Status: PAID`)
  console.log(`- Confirmed: ${new Date().toLocaleString()}`)

  // Simulate email sending delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  return true
}

// Initialize with some sample payment intents for testing
export function initializeSamplePaymentIntents() {
  const now = Date.now()

  paymentIntents = [
    {
      id: "sample-payment-1",
      amount: "25",
      currency: "BRL",
      status: "pending",
      customerInfo: {
        name: "Maria Silva",
        email: "maria@example.com",
        cpf: "123.456.789-00",
      },
      ticketInfo: {
        type: "Ingresso Feminino",
        price: "25",
      },
      paymentCode: "ABCD123456",
      pixCode: PIX_CODES["Ingresso Feminino"],
      createdAt: now - 3600000, // 1 hour ago
      updatedAt: now - 3600000,
      expiresAt: now + 20 * 3600000, // 20 hours from now
    },
    {
      id: "sample-payment-2",
      amount: "40",
      currency: "BRL",
      status: "paid",
      customerInfo: {
        name: "João Santos",
        email: "joao@example.com",
        cpf: "987.654.321-00",
      },
      ticketInfo: {
        type: "Ingresso Masculino",
        price: "40",
      },
      paymentCode: "EFGH789012",
      pixCode: PIX_CODES["Ingresso Masculino"],
      createdAt: now - 86400000, // 1 day ago
      updatedAt: now - 43200000, // 12 hours ago
      expiresAt: now - 43200000, // expired
    },
  ]
}

// Initialize sample payment intents
initializeSamplePaymentIntents()

// Call this function at the end of the file
validatePixCodes()
