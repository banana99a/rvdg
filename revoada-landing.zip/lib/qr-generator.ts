import crypto from "crypto"
import { getTicketByCode, markTicketAsUsed as dbMarkTicketAsUsed } from "./ticket-service"

// Function to generate a secure ticket code
export function generateTicketCode(ticketType: string, userEmail: string): string {
  // Create a unique identifier based on ticket type, email and timestamp
  const timestamp = Date.now()
  const uniqueString = `${ticketType}-${userEmail}-${timestamp}`

  // Create a hash of the unique string
  const hash = crypto.createHash("sha256").update(uniqueString).digest("hex")

  // Return a formatted code (first 12 characters)
  return `RDG-${hash.substring(0, 4)}-${hash.substring(4, 8)}`
}

// Function to verify a ticket code
export function verifyTicketCode(code: string, storedCodes: string[]): boolean {
  // Check if the code exists in our database of valid codes
  return storedCodes.includes(code)
}

// Function to generate QR code data with encryption
export function generateQRData(ticketInfo: {
  code: string
  type: string
  name: string
  email: string
  timestamp: number
}): string {
  // Create a JSON string with ticket information
  const ticketData = JSON.stringify(ticketInfo)

  // Encrypt the data (in a real app, use a proper encryption key)
  // This is a simplified version for demonstration
  const encryptedData = Buffer.from(ticketData).toString("base64")

  return encryptedData
}

// Vamos melhorar a função validateTicket para lidar melhor com diferentes formatos de QR code

export async function validateTicket(ticketData: string): Promise<{
  valid: boolean
  message: string
  ticketInfo?: any
  used?: boolean
}> {
  try {
    // Primeiro, vamos tentar processar como JSON
    let ticketInfo

    try {
      // Tenta interpretar como JSON diretamente
      ticketInfo = JSON.parse(ticketData)
      console.log("Successfully parsed as JSON:", ticketInfo)
    } catch (e) {
      console.log("Not direct JSON, trying other formats")

      // Se não for JSON, verifica se é um código de ticket simples
      if (ticketData.startsWith("RDG-") && ticketData.length >= 10) {
        console.log("Processing as simple ticket code")
        // Busca o ticket no banco de dados
        const ticket = await getTicketByCode(ticketData)

        if (ticket) {
          return {
            valid: !ticket.used,
            message: ticket.used ? "Este ingresso já foi utilizado." : "Ingresso válido!",
            ticketInfo: ticket,
            used: ticket.used,
          }
        } else {
          return {
            valid: false,
            message: "Ingresso não encontrado.",
          }
        }
      } else {
        // Tenta decodificar como base64
        try {
          const decodedData = Buffer.from(ticketData, "base64").toString("utf-8")
          ticketInfo = JSON.parse(decodedData)
          console.log("Successfully parsed from base64:", ticketInfo)
        } catch (e2) {
          console.error("Failed to parse ticket data:", e2)
          return {
            valid: false,
            message: "Formato de QR code inválido ou não reconhecido.",
          }
        }
      }
    }

    // Verifica se o ticket tem os campos necessários
    if (!ticketInfo.code) {
      console.log("Missing code in ticket data")
      return {
        valid: false,
        message: "Ingresso inválido: código ausente.",
      }
    }

    // Busca o ticket no banco de dados para verificar se já foi usado
    const ticket = await getTicketByCode(ticketInfo.code)

    if (!ticket) {
      console.log("Ticket not found in database:", ticketInfo.code)
      return {
        valid: false,
        message: "Ingresso não encontrado no sistema.",
        ticketInfo,
      }
    }

    if (ticket.used) {
      console.log("Ticket already used:", ticketInfo.code)
      return {
        valid: false,
        message: "Este ingresso já foi utilizado.",
        ticketInfo,
        used: true,
      }
    }

    // Verifica se o ticket está expirado (30 dias após a criação)
    const ticketAge = Date.now() - (ticketInfo.timestamp || ticket.timestamp)
    const maxAge = 30 * 24 * 60 * 60 * 1000 // 30 dias em milissegundos

    if (ticketAge > maxAge) {
      console.log("Ticket expired:", ticketInfo.code)
      return {
        valid: false,
        message: "Ingresso expirado.",
        ticketInfo,
      }
    }

    console.log("Valid ticket:", ticketInfo.code)
    return {
      valid: true,
      message: "Ingresso válido!",
      ticketInfo: {
        ...ticket,
        ...ticketInfo,
      },
      used: false,
    }
  } catch (error) {
    console.error("Error validating ticket:", error)
    return {
      valid: false,
      message: "Erro ao validar ingresso.",
    }
  }
}

// Function to mark a ticket as used
export async function markTicketAsUsed(code: string): Promise<boolean> {
  try {
    return await dbMarkTicketAsUsed(code)
  } catch (error) {
    console.error("Error marking ticket as used:", error)
    return false
  }
}
