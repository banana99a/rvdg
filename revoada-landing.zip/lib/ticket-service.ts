// This is a mock service that would normally interact with a database
// In a real application, this would connect to a backend API

interface Ticket {
  code: string
  type: string
  price: string
  name: string
  email: string
  cpf: string
  timestamp: number
  used: boolean
}

// In-memory database for tickets
let tickets: Ticket[] = []

// Admin email for notifications
const ADMIN_EMAIL = "edilsonsgouveia00@gmail.com"

// Create a new ticket
export async function createTicket(ticketData: Ticket): Promise<Ticket> {
  // In a real app, this would be a database insert
  tickets.push(ticketData)

  // Send notification to admin
  await sendAdminNotification(ticketData)

  return ticketData
}

// Get a ticket by code
export async function getTicketByCode(code: string): Promise<Ticket | null> {
  // In a real app, this would be a database query
  const ticket = tickets.find((t) => t.code === code)
  return ticket || null
}

// Get tickets by email
export async function getTicketsByEmail(email: string): Promise<Ticket[]> {
  // In a real app, this would be a database query
  return tickets.filter((t) => t.email.toLowerCase() === email.toLowerCase())
}

// Get tickets by CPF
export async function getTicketsByCPF(cpf: string): Promise<Ticket[]> {
  // In a real app, this would be a database query
  return tickets.filter((t) => t.cpf === cpf)
}

// Mark a ticket as used
export async function markTicketAsUsed(code: string): Promise<boolean> {
  // In a real app, this would be a database update
  const ticketIndex = tickets.findIndex((t) => t.code === code)

  if (ticketIndex === -1) return false

  tickets[ticketIndex].used = true
  return true
}

// Send ticket by email (mock function)
export async function sendTicketByEmail(
  email: string,
  ticketCode: string,
  name: string,
  ticketType: string,
): Promise<boolean> {
  // In a real app, this would send an actual email
  console.log(`Sending ticket ${ticketCode} to ${email}`)

  // Simulate email sending delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  // Also send a copy to admin
  await sendTicketCopyToAdmin(email, ticketCode, name, ticketType)

  return true
}

// Send notification to admin when a new ticket is created
export async function sendAdminNotification(ticket: Ticket): Promise<boolean> {
  // In a real app, this would send an actual email
  console.log(`Sending admin notification to ${ADMIN_EMAIL} for new ticket purchase:`)
  console.log(`- Ticket: ${ticket.type} (${ticket.code})`)
  console.log(`- Customer: ${ticket.name} (${ticket.email})`)
  console.log(`- Price: R$ ${ticket.price}`)
  console.log(`- Date: ${new Date(ticket.timestamp).toLocaleString()}`)

  // Simulate email sending delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  return true
}

// Send a copy of the ticket to admin
export async function sendTicketCopyToAdmin(
  customerEmail: string,
  ticketCode: string,
  customerName: string,
  ticketType: string,
): Promise<boolean> {
  // In a real app, this would send an actual email
  console.log(`Sending ticket copy to admin ${ADMIN_EMAIL}:`)
  console.log(`- Ticket: ${ticketType} (${ticketCode})`)
  console.log(`- Customer: ${customerName} (${customerEmail})`)

  // Simulate email sending delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  return true
}

// Initialize with some sample tickets for testing
export function initializeSampleTickets() {
  tickets = [
    {
      code: "RDG-1234-ABCD",
      type: "Ingresso Feminino",
      price: "25",
      name: "Maria Silva",
      email: "maria@example.com",
      cpf: "123.456.789-00",
      timestamp: Date.now() - 86400000, // 1 day ago
      used: false,
    },
    {
      code: "RDG-5678-EFGH",
      type: "Ingresso Masculino",
      price: "40",
      name: "João Santos",
      email: "joao@example.com",
      cpf: "987.654.321-00",
      timestamp: Date.now() - 172800000, // 2 days ago
      used: true,
    },
  ]
}

// Initialize sample tickets
initializeSampleTickets()
