"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { validateTicket } from "@/lib/qr-generator"
import { getTicketByCode } from "@/lib/ticket-service"

export function DebugQrScanner() {
  const [debugMode, setDebugMode] = useState(false)
  const [testCode, setTestCode] = useState("")
  const [result, setResult] = useState<any>(null)
  const [rawTicket, setRawTicket] = useState<any>(null)

  const handleTest = async () => {
    if (!testCode) return

    try {
      console.log("Testing code:", testCode)

      // Try to get the raw ticket first
      const ticket = await getTicketByCode(testCode)
      setRawTicket(ticket)

      // Then validate it
      const validationResult = await validateTicket(testCode)
      setResult(validationResult)
    } catch (error) {
      console.error("Debug test error:", error)
      setResult({
        valid: false,
        message: `Erro: ${error instanceof Error ? error.message : "Desconhecido"}`,
      })
    }
  }

  if (!debugMode) {
    return (
      <div className="fixed bottom-4 right-4">
        <Button variant="outline" size="sm" className="bg-gray-800/50 text-xs" onClick={() => setDebugMode(true)}>
          Debug Scanner
        </Button>
      </div>
    )
  }

  return (
    <div className="fixed bottom-0 right-0 w-full md:w-96 bg-gray-900/90 p-4 rounded-t-lg border border-gray-700 z-50">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-sm font-bold">Debug Scanner</h3>
        <Button variant="ghost" size="sm" onClick={() => setDebugMode(false)}>
          Fechar
        </Button>
      </div>

      <div className="space-y-3">
        <div>
          <label className="block text-xs mb-1">Código de Teste:</label>
          <div className="flex gap-2">
            <input
              type="text"
              value={testCode}
              onChange={(e) => setTestCode(e.target.value)}
              className="flex-1 bg-gray-800 border border-gray-700 rounded px-2 py-1 text-sm"
              placeholder="RDG-1234-ABCD ou JSON"
            />
            <Button size="sm" onClick={handleTest}>
              Testar
            </Button>
          </div>
        </div>

        {rawTicket && (
          <div className="bg-gray-800/50 p-2 rounded text-xs">
            <p className="font-bold mb-1">Ticket Raw:</p>
            <pre className="overflow-auto max-h-20">{JSON.stringify(rawTicket, null, 2)}</pre>
          </div>
        )}

        {result && (
          <div className="bg-gray-800/50 p-2 rounded text-xs">
            <p className="font-bold mb-1">Resultado:</p>
            <div className={`p-1 rounded mb-2 ${result.valid ? "bg-green-900/30" : "bg-red-900/30"}`}>
              <span className={result.valid ? "text-green-400" : "text-red-400"}>
                {result.valid ? "✓ Válido" : "✗ Inválido"}
              </span>
              : {result.message}
            </div>
            <pre className="overflow-auto max-h-40">{JSON.stringify(result, null, 2)}</pre>
          </div>
        )}
      </div>
    </div>
  )
}
