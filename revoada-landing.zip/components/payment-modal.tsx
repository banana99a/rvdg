"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Copy, Check } from "lucide-react"
import QRCode from "react-qr-code"

interface PaymentModalProps {
  isOpen: boolean
  onClose: () => void
  ticketType: string
  price: string
}

export function PaymentModal({ isOpen, onClose, ticketType, price }: PaymentModalProps) {
  const [copied, setCopied] = useState(false)
  const phoneNumber = "19994027338"
  const pixMessage = `Revoada do Gouveia - Ingresso ${ticketType} - R$ ${price}`

  const handleCopy = () => {
    navigator.clipboard.writeText(phoneNumber)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-purple-900 text-white border-purple-700 max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-center">Pagamento - {ticketType}</DialogTitle>
          <DialogDescription className="text-gray-300 text-center">
            Faça o pagamento via PIX para garantir seu ingresso
          </DialogDescription>
        </DialogHeader>

        <div className="bg-white p-4 rounded-lg mx-auto">
          <QRCode
            value={`00020126330014br.gov.bcb.pix011148370885896520400005303986540525.005802BR5924Edilson Dos Santos Gouve6008Brasilia62240520daqr1064735690745860630443F8`}
            size={180}
          />
        </div>

        <div className="space-y-4">
          <div className="bg-purple-800/50 p-3 rounded-lg">
            <p className="text-sm text-gray-300 mb-1">Telefone/PIX:</p>
            <div className="flex items-center justify-between">
              <p className="font-mono font-bold">{phoneNumber}</p>
              <Button variant="ghost" size="icon" onClick={handleCopy} className="h-8 w-8">
                {copied ? <Check className="h-4 w-4 text-green-400" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          <div className="bg-purple-800/50 p-3 rounded-lg">
            <p className="text-sm text-gray-300 mb-1">Valor:</p>
            <p className="font-bold text-xl">R$ {price}</p>
          </div>

          <div className="text-sm text-gray-300">
            <p>1. Faça o pagamento via PIX para o número acima</p>
            <p>2. Envie o comprovante para o WhatsApp (19) 99402-7338</p>
            <p>3. Você receberá seu QR Code de entrada em até 24h</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
