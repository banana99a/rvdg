"use client"

import { useState, useRef, useEffect } from "react"
import { Html5Qrcode } from "html5-qrcode"
import { motion } from "framer-motion"
import { X, Check, AlertTriangle } from "lucide-react"
import { validateTicket, markTicketAsUsed } from "@/lib/qr-generator"

interface QrScannerProps {
  onScanSuccess: (decodedText: string) => void
  onClose: () => void
}

export function QrScanner({ onScanSuccess, onClose }: QrScannerProps) {
  const [error, setError] = useState<string | null>(null)
  const [scanning, setScanning] = useState(false)
  const [validationResult, setValidationResult] = useState<{
    valid: boolean
    message: string
    ticketInfo?: any
    used?: boolean
  } | null>(null)
  const [processing, setProcessing] = useState(false)
  const scannerRef = useRef<Html5Qrcode | null>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Initialize scanner
    if (containerRef.current) {
      const qrCodeId = "qr-reader"

      // Create scanner container if it doesn't exist
      if (!document.getElementById(qrCodeId)) {
        const element = document.createElement("div")
        element.id = qrCodeId
        containerRef.current.appendChild(element)
      }

      // Initialize scanner
      scannerRef.current = new Html5Qrcode(qrCodeId)

      // Start scanning
      startScanner()
    }

    // Cleanup on unmount
    return () => {
      if (scannerRef.current && scannerRef.current.isScanning) {
        scannerRef.current.stop().catch((error) => console.error("Error stopping scanner:", error))
      }
    }
  }, [])

  const startScanner = async () => {
    if (!scannerRef.current) return

    try {
      setScanning(true)
      setError(null)
      setValidationResult(null)

      // Vamos corrigir o problema de leitura do QR code
      // O problema principal está na forma como estamos processando o QR code após a leitura

      // Na função qrCodeSuccessCallback, vamos melhorar o tratamento do QR code lido
      const qrCodeSuccessCallback = async (decodedText: string) => {
        // Stop scanning after successful scan
        if (scannerRef.current) {
          scannerRef.current.stop().catch((error) => console.error("Error stopping scanner:", error))
        }

        setProcessing(true)

        try {
          // Primeiro, vamos tentar processar como JSON
          let ticketData
          let isJson = false

          try {
            ticketData = JSON.parse(decodedText)
            isJson = true
          } catch (e) {
            // Não é JSON, pode ser um código simples ou um payload base64
            console.log("Not JSON, trying as plain code:", decodedText)
            ticketData = decodedText
          }

          // Validar o ticket
          const result = validateTicket(decodedText)

          // Se válido, verificar se já foi usado e marcar como usado
          if (result.valid && result.ticketInfo) {
            const ticketCode = result.ticketInfo.code
            const wasMarked = await markTicketAsUsed(ticketCode)

            if (wasMarked) {
              setValidationResult({
                ...result,
                message: "Ingresso validado com sucesso!",
              })
            } else {
              setValidationResult({
                valid: false,
                message: "Erro ao marcar ingresso como utilizado.",
                ticketInfo: result.ticketInfo,
              })
            }
          } else {
            setValidationResult(result)
          }
        } catch (error) {
          console.error("Error validating ticket:", error)
          setValidationResult({
            valid: false,
            message: "Erro ao validar o QR code.",
          })
        } finally {
          setProcessing(false)
        }

        // Call the success callback with the decoded text
        onScanSuccess(decodedText)
      }

      const config = {
        fps: 10,
        qrbox: { width: 250, height: 250 },
        aspectRatio: 1.0,
      }

      await scannerRef.current.start(
        { facingMode: "environment" }, // Use back camera on mobile devices
        config,
        qrCodeSuccessCallback,
        (errorMessage) => {
          // This is a continuous error callback, we don't want to show these
          // Only show critical errors that prevent scanning
          if (errorMessage.includes("Camera access denied") || errorMessage.includes("No camera")) {
            setError(errorMessage)
          }
        },
      )
    } catch (err) {
      setScanning(false)
      setError("Erro ao iniciar o scanner. Por favor, verifique as permissões da câmera.")
      console.error("Error starting scanner:", err)
    }
  }

  const handleScanAgain = () => {
    setValidationResult(null)
    startScanner()
  }

  return (
    <motion.div
      className="fixed inset-0 bg-black/80 z-50 flex flex-col items-center justify-center p-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <div className="bg-purple-900 rounded-lg p-4 w-full max-w-md relative">
        <button
          onClick={onClose}
          className="absolute top-2 right-2 w-8 h-8 flex items-center justify-center rounded-full bg-purple-800"
        >
          <X size={18} />
        </button>

        <h3 className="text-xl font-bold mb-4 text-center">
          {validationResult ? "Resultado da Verificação" : "Escanear QR Code"}
        </h3>

        {!validationResult ? (
          <>
            <div ref={containerRef} className="w-full aspect-square bg-black rounded-lg overflow-hidden mb-4">
              {/* Scanner will be mounted here */}
            </div>

            {error && <div className="bg-red-900/30 text-red-200 p-3 rounded-md text-sm mb-4">{error}</div>}

            <p className="text-sm text-gray-300 text-center">
              Posicione o QR Code do ingresso no centro da câmera para verificar.
            </p>
          </>
        ) : (
          <div className="p-2">
            <div className="flex justify-center mb-6">
              {validationResult.valid ? (
                <div className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center">
                  <Check className="w-8 h-8 text-green-400" />
                </div>
              ) : (
                <div className="w-16 h-16 rounded-full bg-red-500/20 flex items-center justify-center">
                  <AlertTriangle className="w-8 h-8 text-red-400" />
                </div>
              )}
            </div>

            <h4
              className={`text-lg font-bold text-center mb-4 ${validationResult.valid ? "text-green-400" : "text-red-400"}`}
            >
              {validationResult.message}
            </h4>

            {validationResult.ticketInfo && (
              <div className="space-y-3 mb-6">
                <div className="bg-purple-800/50 p-3 rounded-lg">
                  <p className="text-sm text-gray-300 mb-1">Nome:</p>
                  <p className="font-bold">{validationResult.ticketInfo.name}</p>
                </div>

                <div className="bg-purple-800/50 p-3 rounded-lg">
                  <p className="text-sm text-gray-300 mb-1">Tipo de Ingresso:</p>
                  <p className="font-bold">{validationResult.ticketInfo.type}</p>
                </div>

                <div className="bg-purple-800/50 p-3 rounded-lg">
                  <p className="text-sm text-gray-300 mb-1">Código:</p>
                  <p className="font-mono text-sm">{validationResult.ticketInfo.code}</p>
                </div>
              </div>
            )}

            <div className="flex gap-3">
              <button onClick={onClose} className="flex-1 py-2 border border-gray-600 rounded-md">
                Fechar
              </button>

              <button
                onClick={handleScanAgain}
                className="flex-1 py-2 bg-gradient-to-r from-pink-500 to-pink-600 rounded-md"
              >
                Escanear Outro
              </button>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  )
}
