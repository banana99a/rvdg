"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { QrCode, Scan } from "lucide-react"
import { AnimatedIcon } from "./animated-icon"
import { QrScanner } from "./qr-scanner"
import { validateTicket } from "@/lib/qr-generator"
import { TicketVerificationResult } from "./ticket-verification-result"

// Mock database of valid ticket codes
const VALID_TICKETS = ["RDG-1234-ABCD", "RDG-5678-EFGH", "RDG-9012-IJKL"]

export function SecureQrVerification() {
  const [ticketCode, setTicketCode] = useState("")
  const [verificationResult, setVerificationResult] = useState<null | {
    valid: boolean
    message: string
    ticketInfo?: any
  }>(null)
  const [isVerifying, setIsVerifying] = useState(false)
  const [showScanner, setShowScanner] = useState(false)

  const handleVerify = () => {
    if (!ticketCode) return

    setIsVerifying(true)

    // Simulate API verification delay
    setTimeout(() => {
      // Check if it's a simple code or a QR code payload
      if (ticketCode.startsWith("{") && ticketCode.endsWith("}")) {
        try {
          // It's a JSON payload
          const ticketData = JSON.parse(ticketCode)

          if (ticketData.code && VALID_TICKETS.includes(ticketData.code)) {
            setVerificationResult({
              valid: true,
              message: "Ingresso válido! Apresente este código na entrada do evento.",
              ticketInfo: ticketData,
            })
          } else {
            setVerificationResult({
              valid: false,
              message: "Ingresso inválido ou não encontrado. Verifique o código ou entre em contato.",
            })
          }
        } catch (error) {
          setVerificationResult({
            valid: false,
            message: "Formato de QR code inválido. Tente novamente.",
          })
        }
      } else {
        // It's a simple code
        const isValid = VALID_TICKETS.includes(ticketCode)

        setVerificationResult({
          valid: isValid,
          message: isValid
            ? "Ingresso válido! Apresente este código na entrada do evento."
            : "Ingresso inválido ou não encontrado. Verifique o código ou entre em contato.",
        })
      }

      setIsVerifying(false)
    }, 1500)
  }

  const handleScanSuccess = (decodedText: string) => {
    setShowScanner(false)
    setTicketCode(decodedText)

    // Auto-verify after scan
    setTimeout(() => {
      setIsVerifying(true)
      setTimeout(async () => {
        try {
          console.log("Verifying scanned code:", decodedText)

          // Validar o ticket usando a função melhorada
          const validationResult = await validateTicket(decodedText)
          setVerificationResult(validationResult)
        } catch (error) {
          console.error("Error during verification:", error)

          // Verificar se é um código simples
          const isValid = decodedText.startsWith("RDG-") && decodedText.length >= 10

          setVerificationResult({
            valid: isValid,
            message: isValid
              ? "Ingresso válido! Apresente este código na entrada do evento."
              : "QR Code inválido. Este não parece ser um ingresso para o evento.",
          })
        }

        setIsVerifying(false)
      }, 1500)
    }, 500)
  }

  return (
    <div className="py-12 px-4 max-w-5xl mx-auto">
      <div className="flex justify-center mb-4">
        <AnimatedIcon color="text-pink-400" hoverScale={1.2}>
          <QrCode className="w-12 h-12" />
        </AnimatedIcon>
      </div>

      <motion.h2
        className="text-2xl font-bold text-center mb-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        Já comprou seu ingresso?
      </motion.h2>

      <motion.p
        className="text-center text-gray-300 mb-8"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        Verifique o status do seu ingresso ou acesse o QR code para apresentar na entrada do evento.
      </motion.p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <motion.div initial={{ x: -20, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ delay: 0.4 }}>
          <button className="w-full bg-gradient-to-r from-pink-500 to-pink-600 py-3 rounded-md font-medium">
            Código Manual
          </button>
        </motion.div>
        <motion.div initial={{ x: 20, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ delay: 0.5 }}>
          <button
            className="w-full bg-transparent border border-gray-600 py-3 rounded-md font-medium flex items-center justify-center gap-2"
            onClick={() => setShowScanner(true)}
          >
            <Scan className="w-4 h-4" />
            Escanear QR Code
          </button>
        </motion.div>
      </div>

      <motion.div
        className="mb-4"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.6 }}
      >
        <label className="block text-sm mb-2">Código do Ingresso</label>
        <input
          type="text"
          value={ticketCode}
          onChange={(e) => setTicketCode(e.target.value)}
          placeholder="Ex: RDG-1234-ABCD"
          className="w-full bg-purple-950 border border-purple-800 rounded-md p-3 text-white"
        />
      </motion.div>

      <motion.button
        className="w-full bg-gradient-to-r from-pink-500 to-pink-600 py-3 rounded-md font-medium flex items-center justify-center"
        onClick={handleVerify}
        whileTap={{ scale: 0.98 }}
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.7 }}
      >
        {isVerifying ? (
          <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full mr-2"></div>
        ) : null}
        Verificar Ingresso
      </motion.button>

      {verificationResult !== null && (
        <TicketVerificationResult
          isValid={verificationResult.valid}
          message={verificationResult.message}
          ticketInfo={verificationResult.ticketInfo}
        />
      )}

      <AnimatePresence>
        {showScanner && <QrScanner onScanSuccess={handleScanSuccess} onClose={() => setShowScanner(false)} />}
      </AnimatePresence>
    </div>
  )
}
