"use client"

import { motion } from "framer-motion"
import { Check, X, User, Calendar, Ticket } from "lucide-react"

interface TicketVerificationResultProps {
  isValid: boolean
  message: string
  ticketInfo?: {
    code: string
    type: string
    name: string
    email: string
    timestamp: number
  }
}

export function TicketVerificationResult({ isValid, message, ticketInfo }: TicketVerificationResultProps) {
  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp)
    return date.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <motion.div
      className={`mt-4 p-4 rounded-md ${isValid ? "bg-green-900/30" : "bg-red-900/30"}`}
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: "auto" }}
    >
      <div className="flex items-center mb-3">
        {isValid ? (
          <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center mr-3">
            <Check className="w-5 h-5 text-green-400" />
          </div>
        ) : (
          <div className="w-8 h-8 rounded-full bg-red-500/20 flex items-center justify-center mr-3">
            <X className="w-5 h-5 text-red-400" />
          </div>
        )}
        <span className="font-medium">{message}</span>
      </div>

      {isValid && ticketInfo && (
        <div className="mt-4 space-y-3">
          <div className="flex items-center text-sm">
            <User className="w-4 h-4 mr-2 text-gray-400" />
            <span className="text-gray-300">Nome:</span>
            <span className="ml-2 font-medium">{ticketInfo.name}</span>
          </div>

          <div className="flex items-center text-sm">
            <Ticket className="w-4 h-4 mr-2 text-gray-400" />
            <span className="text-gray-300">Tipo:</span>
            <span className="ml-2 font-medium">{ticketInfo.type}</span>
          </div>

          <div className="flex items-center text-sm">
            <Calendar className="w-4 h-4 mr-2 text-gray-400" />
            <span className="text-gray-300">Emitido em:</span>
            <span className="ml-2 font-medium">{formatDate(ticketInfo.timestamp)}</span>
          </div>

          <div className="bg-purple-800/30 p-3 rounded-md text-sm mt-3">
            <p className="font-medium mb-1">Código do Ingresso:</p>
            <p className="font-mono">{ticketInfo.code}</p>
          </div>
        </div>
      )}
    </motion.div>
  )
}
