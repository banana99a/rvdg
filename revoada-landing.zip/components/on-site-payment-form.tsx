"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { Check, Upload, User, Mail, Phone, Calendar, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { generateTicketCode } from "@/lib/qr-generator"
import QRCode from "react-qr-code"

interface OnSitePaymentFormProps {
  ticketType: string
  price: string
  onClose: () => void
}

export function OnSitePaymentForm({ ticketType, price, onClose }: OnSitePaymentFormProps) {
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    birthdate: "",
  })
  const [paymentProof, setPaymentProof] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [ticketCode, setTicketCode] = useState("")
  const [showTicket, setShowTicket] = useState(false)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      setPaymentProof(file)

      // Create preview URL
      const reader = new FileReader()
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmitInfo = (e: React.FormEvent) => {
    e.preventDefault()
    // Validate form
    if (!formData.name || !formData.email || !formData.phone) {
      alert("Por favor, preencha todos os campos obrigatórios.")
      return
    }

    // Move to payment proof step
    setStep(2)
  }

  const handleSubmitPayment = (e: React.FormEvent) => {
    e.preventDefault()

    if (!paymentProof) {
      alert("Por favor, envie o comprovante de pagamento.")
      return
    }

    setIsSubmitting(true)

    // Simulate API call to verify payment
    setTimeout(() => {
      // Generate ticket code
      const code = generateTicketCode(ticketType, formData.email)
      setTicketCode(code)

      setIsSubmitting(false)
      setStep(3)
    }, 2000)
  }

  const handleViewTicket = () => {
    setShowTicket(true)
  }

  return (
    <div className="bg-purple-900/90 rounded-lg p-6 max-w-md mx-auto">
      {/* Progress indicator */}
      <div className="flex items-center justify-between mb-6">
        <div className={`w-1/3 h-1 ${step >= 1 ? "bg-pink-500" : "bg-gray-600"} rounded-l-full`}></div>
        <div className={`w-1/3 h-1 ${step >= 2 ? "bg-pink-500" : "bg-gray-600"}`}></div>
        <div className={`w-1/3 h-1 ${step >= 3 ? "bg-pink-500" : "bg-gray-600"} rounded-r-full`}></div>
      </div>

      {/* Step 1: Personal Information */}
      {step === 1 && (
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
          <h2 className="text-xl font-bold mb-4">Informações Pessoais</h2>
          <p className="text-gray-300 mb-6">
            Preencha seus dados para reservar seu ingresso {ticketType} por R$ {price}
          </p>

          <form onSubmit={handleSubmitInfo} className="space-y-4">
            <div>
              <label className="block text-sm mb-1">Nome Completo*</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  className="w-full bg-purple-950 border border-purple-800 rounded-md p-3 pl-10 text-white"
                  placeholder="Seu nome completo"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm mb-1">E-mail*</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="w-full bg-purple-950 border border-purple-800 rounded-md p-3 pl-10 text-white"
                  placeholder="seu.email@exemplo.com"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm mb-1">Telefone*</label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  className="w-full bg-purple-950 border border-purple-800 rounded-md p-3 pl-10 text-white"
                  placeholder="(00) 00000-0000"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm mb-1">Data de Nascimento</label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="date"
                  name="birthdate"
                  value={formData.birthdate}
                  onChange={handleInputChange}
                  className="w-full bg-purple-950 border border-purple-800 rounded-md p-3 pl-10 text-white"
                />
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <Button type="button" variant="outline" onClick={onClose} className="flex-1">
                Cancelar
              </Button>
              <Button type="submit" className="flex-1 bg-gradient-to-r from-pink-500 to-pink-600">
                Próximo
              </Button>
            </div>
          </form>
        </motion.div>
      )}

      {/* Step 2: Payment Proof */}
      {step === 2 && (
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
          <h2 className="text-xl font-bold mb-4">Comprovante de Pagamento</h2>
          <p className="text-gray-300 mb-6">Faça o pagamento de R$ {price} no local e envie o comprovante abaixo</p>

          <div className="bg-purple-800/50 p-4 rounded-lg mb-6">
            <h3 className="font-medium mb-2">Instruções de Pagamento:</h3>
            <ol className="text-sm text-gray-300 space-y-2 list-decimal list-inside">
              <li>Dirija-se ao caixa do evento</li>
              <li>Informe que deseja comprar o ingresso {ticketType}</li>
              <li>Efetue o pagamento de R$ {price}</li>
              <li>Solicite um comprovante</li>
              <li>Tire uma foto do comprovante e envie abaixo</li>
            </ol>
          </div>

          <form onSubmit={handleSubmitPayment} className="space-y-4">
            <div className="border-2 border-dashed border-purple-700 rounded-lg p-4 text-center">
              {previewUrl ? (
                <div className="relative">
                  <img src={previewUrl || "/placeholder.svg"} alt="Comprovante" className="max-h-48 mx-auto rounded" />
                  <button
                    type="button"
                    onClick={() => {
                      setPaymentProof(null)
                      setPreviewUrl(null)
                    }}
                    className="absolute top-2 right-2 bg-red-500 rounded-full p-1"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <label className="cursor-pointer block py-8">
                  <Upload className="w-10 h-10 mx-auto mb-2 text-gray-400" />
                  <p className="text-gray-300">Clique para enviar o comprovante</p>
                  <p className="text-xs text-gray-400 mt-1">Formatos aceitos: JPG, PNG, PDF</p>
                  <input type="file" accept="image/*,.pdf" onChange={handleFileChange} className="hidden" />
                </label>
              )}
            </div>

            <div className="flex gap-3 pt-4">
              <Button type="button" variant="outline" onClick={() => setStep(1)} className="flex-1">
                Voltar
              </Button>
              <Button
                type="submit"
                className="flex-1 bg-gradient-to-r from-pink-500 to-pink-600"
                disabled={!paymentProof || isSubmitting}
              >
                {isSubmitting ? (
                  <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"></div>
                ) : (
                  "Enviar Comprovante"
                )}
              </Button>
            </div>
          </form>
        </motion.div>
      )}

      {/* Step 3: Confirmation */}
      {step === 3 && (
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center">
          <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <Check className="w-8 h-8 text-green-400" />
          </div>

          <h2 className="text-xl font-bold mb-2">Pagamento Confirmado!</h2>
          <p className="text-gray-300 mb-6">Seu ingresso {ticketType} foi gerado com sucesso.</p>

          <div className="bg-purple-800/50 p-4 rounded-lg mb-6">
            <p className="text-sm text-gray-300 mb-2">Código do Ingresso:</p>
            <p className="font-mono font-bold">{ticketCode}</p>
          </div>

          <div className="flex gap-3">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              Fechar
            </Button>
            <Button
              type="button"
              className="flex-1 bg-gradient-to-r from-pink-500 to-pink-600"
              onClick={handleViewTicket}
            >
              Ver Ingresso
            </Button>
          </div>
        </motion.div>
      )}

      {/* Ticket Modal */}
      <Dialog open={showTicket} onOpenChange={setShowTicket}>
        <DialogContent className="bg-purple-900 text-white border-purple-700 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-center">Seu Ingresso</DialogTitle>
          </DialogHeader>

          <div className="bg-white p-6 rounded-lg mx-auto">
            <QRCode
              value={JSON.stringify({
                code: ticketCode,
                type: ticketType,
                name: formData.name,
                email: formData.email,
                timestamp: Date.now(),
              })}
              size={200}
              className="mx-auto"
            />
          </div>

          <div className="space-y-4 mt-4">
            <div className="bg-purple-800/50 p-3 rounded-lg">
              <p className="text-sm text-gray-300 mb-1">Nome:</p>
              <p className="font-bold">{formData.name}</p>
            </div>

            <div className="bg-purple-800/50 p-3 rounded-lg">
              <p className="text-sm text-gray-300 mb-1">Tipo de Ingresso:</p>
              <p className="font-bold">
                {ticketType} - R$ {price}
              </p>
            </div>

            <div className="bg-purple-800/50 p-3 rounded-lg">
              <p className="text-sm text-gray-300 mb-1">Código:</p>
              <p className="font-mono text-sm">{ticketCode}</p>
            </div>

            <div className="text-sm text-gray-300 text-center">
              <p>Apresente este QR Code na entrada do evento.</p>
              <p>Não compartilhe seu ingresso com outras pessoas.</p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
