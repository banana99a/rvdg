"use client"

import type React from "react"

import { useState } from "react"
import { AnimatedIcon } from "./animated-icon"
import { motion } from "framer-motion"
import { CheckoutForm } from "./checkout-form"

interface TicketCardProps {
  icon: React.ReactNode
  title: string
  description: string
  price: string
  color: string
  buttonColor: string
  iconBgColor: string
}

export function TicketCard({ icon, title, description, price, color, buttonColor, iconBgColor }: TicketCardProps) {
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false)

  return (
    <motion.div
      className={`bg-purple-900/40 rounded-lg p-6 border-t-4 ${color}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      whileHover={{ y: -5 }}
    >
      <div className="flex justify-center mb-4">
        <div className={`w-12 h-12 rounded-full ${iconBgColor} flex items-center justify-center`}>
          <AnimatedIcon>{icon}</AnimatedIcon>
        </div>
      </div>
      <h3 className="text-xl font-bold text-center mb-1">{title}</h3>
      <p className="text-sm text-center text-gray-300 mb-4">{description}</p>
      <p className="text-3xl font-bold text-center mb-6">R$ {price}</p>

      <motion.button
        className={`w-full ${buttonColor} py-3 rounded-md font-medium`}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsCheckoutOpen(true)}
      >
        Comprar Agora
      </motion.button>

      {isCheckoutOpen && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="max-w-md w-full">
            <CheckoutForm ticketType={title} price={price} onClose={() => setIsCheckoutOpen(false)} />
          </div>
        </div>
      )}
    </motion.div>
  )
}
