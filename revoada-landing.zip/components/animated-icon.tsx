"use client"

import { motion } from "framer-motion"
import type { ReactNode } from "react"

interface AnimatedIconProps {
  children: ReactNode
  color?: string
  hoverScale?: number
  initialScale?: number
  className?: string
  pulse?: boolean
}

export function AnimatedIcon({
  children,
  color = "text-pink-400",
  hoverScale = 1.1,
  initialScale = 1,
  className = "",
  pulse = false,
}: AnimatedIconProps) {
  return (
    <motion.div
      className={`${color} ${className}`}
      initial={{ scale: initialScale }}
      animate={
        pulse
          ? {
              scale: [initialScale, initialScale * 1.1, initialScale],
              rotate: [0, -3, 3, -3, 0],
            }
          : { scale: initialScale }
      }
      whileHover={{ scale: hoverScale, rotate: [0, -10, 10, -10, 0] }}
      transition={{
        type: "spring",
        stiffness: 260,
        damping: 20,
        scale: {
          duration: pulse ? 2 : 0.3,
          repeat: pulse ? Number.POSITIVE_INFINITY : 0,
          repeatType: "reverse",
        },
        rotate: {
          duration: 0.5,
          ease: "easeInOut",
        },
      }}
    >
      {children}
    </motion.div>
  )
}
