"use client"

import { motion } from "framer-motion"

export function AnimatedCrown() {
  return (
    <motion.div
      initial={{ scale: 0 }}
      animate={{ scale: 1, rotate: [0, -5, 5, -5, 0] }}
      transition={{
        type: "spring",
        stiffness: 260,
        damping: 20,
        rotate: {
          duration: 1,
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "loop",
          repeatDelay: 3,
        },
      }}
      whileHover={{
        scale: 1.2,
        rotate: [0, -10, 10, -10, 0],
        transition: {
          rotate: {
            duration: 0.5,
            repeat: 0,
          },
        },
      }}
    >
      <svg width="60" height="60" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <motion.path
          d="M3 11L12 2L21 11V22H3V11Z"
          fill="#FFD700"
          stroke="#FFD700"
          strokeWidth="2"
          initial={{ opacity: 0.7 }}
          animate={{
            opacity: [0.7, 1, 0.7],
            fill: ["#FFD700", "#FFC000", "#FFD700"],
          }}
          transition={{
            duration: 2,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
          }}
        />
        <motion.path
          d="M8 2L8 7L16 7L16 2"
          stroke="#FFD700"
          strokeWidth="2"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{
            duration: 1.5,
            ease: "easeInOut",
            delay: 0.5,
          }}
        />
        <motion.circle
          cx="12"
          cy="14"
          r="1.5"
          fill="#FFFFFF"
          initial={{ opacity: 0, scale: 0 }}
          animate={{
            opacity: [0, 1, 0],
            scale: [0, 1, 0],
          }}
          transition={{
            duration: 2,
            repeat: Number.POSITIVE_INFINITY,
            repeatDelay: 1,
          }}
        />
      </svg>
    </motion.div>
  )
}
