"use client"

import type React from "react"

import { useState } from "react"
import { User, Mail, CreditCard } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import { createPaymentIntent } from "@/lib/payment-service"

interface CheckoutFormProps {
  ticketType: string
  price: string
  onClose: () => void
}

export function CheckoutForm({ ticketType, price, onClose }: CheckoutFormProps) {
  const router = useRouter()
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    cpf: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))

    // Clear error when typing
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }))
    }
  }

  // Format CPF as user types (000.000.000-00)
  const formatCPF = (value: string) => {
    const numbers = value.replace(/\D/g, "")
    if (numbers.length <= 3) return numbers
    if (numbers.length <= 6) return `${numbers.slice(0, 3)}.${numbers.slice(3)}`
    if (numbers.length <= 9) return `${numbers.slice(0, 3)}.${numbers.slice(3, 6)}.${numbers.slice(6)}`
    return `${numbers.slice(0, 3)}.${numbers.slice(3, 6)}.${numbers.slice(6, 9)}-${numbers.slice(9, 11)}`
  }

  const handleCPFChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formattedCPF = formatCPF(e.target.value)
    setFormData((prev) => ({ ...prev, cpf: formattedCPF }))

    if (errors.cpf) {
      setErrors((prev) => ({ ...prev, cpf: "" }))
    }
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.name.trim()) {
      newErrors.name = "Nome é obrigatório"
    }

    if (!formData.email.trim()) {
      newErrors.email = "E-mail é obrigatório"
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "E-mail inválido"
    }

    if (!formData.cpf.trim()) {
      newErrors.cpf = "CPF é obrigatório"
    } else if (formData.cpf.replace(/\D/g, "").length !== 11) {
      newErrors.cpf = "CPF inválido"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) return

    setIsSubmitting(true)

    try {
      // Create payment intent
      const paymentIntent = await createPaymentIntent({
        customerInfo: {
          name: formData.name,
          email: formData.email,
          cpf: formData.cpf,
        },
        ticketInfo: {
          type: ticketType,
          price,
        },
      })

      // Redirect to payment page
      router.push(`/payment/${paymentIntent.id}`)
    } catch (error) {
      console.error("Error creating payment intent:", error)
      setIsSubmitting(false)
      alert("Ocorreu um erro ao processar seu pedido. Por favor, tente novamente.")
    }
  }

  return (
    <div className="bg-purple-900/90 rounded-lg p-6 max-w-md mx-auto">
      <div className="flex justify-center mb-4">
        <div className="w-12 h-12 rounded-full bg-pink-500/20 flex items-center justify-center">
          <CreditCard className="w-6 h-6 text-pink-400" />
        </div>
      </div>

      <h2 className="text-xl font-bold text-center mb-2">Checkout</h2>
      <p className="text-gray-300 text-center mb-6">
        {ticketType} - R$ {price}
      </p>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm mb-1">Nome Completo*</label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              className={`w-full bg-purple-950 border ${errors.name ? "border-red-500" : "border-purple-800"} rounded-md p-3 pl-10 text-white`}
              placeholder="Seu nome completo"
            />
          </div>
          {errors.name && <p className="text-red-400 text-xs mt-1">{errors.name}</p>}
        </div>

        <div>
          <label className="block text-sm mb-1">E-mail*</label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
              className={`w-full bg-purple-950 border ${errors.email ? "border-red-500" : "border-purple-800"} rounded-md p-3 pl-10 text-white`}
              placeholder="seu.email@exemplo.com"
            />
          </div>
          {errors.email && <p className="text-red-400 text-xs mt-1">{errors.email}</p>}
        </div>

        <div>
          <label className="block text-sm mb-1">CPF*</label>
          <div className="relative">
            <svg
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <rect x="3" y="4" width="18" height="16" rx="2" />
              <line x1="7" y1="12" x2="17" y2="12" />
              <line x1="7" y1="8" x2="10" y2="8" />
              <line x1="7" y1="16" x2="10" y2="16" />
            </svg>
            <input
              type="text"
              name="cpf"
              value={formData.cpf}
              onChange={handleCPFChange}
              maxLength={14}
              className={`w-full bg-purple-950 border ${errors.cpf ? "border-red-500" : "border-purple-800"} rounded-md p-3 pl-10 text-white`}
              placeholder="000.000.000-00"
            />
          </div>
          {errors.cpf && <p className="text-red-400 text-xs mt-1">{errors.cpf}</p>}
        </div>

        <div className="bg-purple-800/30 p-3 rounded-md text-sm">
          <p className="font-medium mb-1">Resumo da compra:</p>
          <div className="flex justify-between mb-1">
            <span>Ingresso {ticketType}</span>
            <span>R$ {price}</span>
          </div>
          <div className="flex justify-between font-bold border-t border-purple-700 pt-2 mt-2">
            <span>Total</span>
            <span>R$ {price}</span>
          </div>
        </div>

        <div className="flex gap-3 pt-4">
          <Button type="button" variant="outline" onClick={onClose} className="flex-1">
            Cancelar
          </Button>
          <Button type="submit" className="flex-1 bg-gradient-to-r from-pink-500 to-pink-600" disabled={isSubmitting}>
            {isSubmitting ? (
              <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"></div>
            ) : (
              "Continuar"
            )}
          </Button>
        </div>
      </form>
    </div>
  )
}
