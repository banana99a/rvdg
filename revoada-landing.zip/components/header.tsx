"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import { Ticket } from "lucide-react"

export function Header() {
  return (
    <motion.header
      className="flex justify-between items-center p-4"
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <Link href="/" className="text-pink-500 font-bold">
        REVOADA DO GOUVEIA 6.0
      </Link>

      <div className="flex gap-2">
        <Link href="/meus-ingressos">
          <motion.button
            className="px-4 py-2 rounded-full border border-white/30 text-white text-sm flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Ticket className="w-4 h-4" />
            Meus Ingressos
          </motion.button>
        </Link>

        <motion.button
          className="px-4 py-2 rounded-full bg-gradient-to-r from-pink-500 to-pink-600 text-white text-sm"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          
        </motion.button>
      </div>
    </motion.header>
  )
}
