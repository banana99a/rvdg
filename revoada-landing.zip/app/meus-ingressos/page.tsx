"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Search, Ticket, Mail, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { getTicketsByEmail, getTicketsByCPF } from "@/lib/ticket-service"
import Link from "next/link"
import QRCode from "react-qr-code"

export default function MyTickets() {
  const [searchType, setSearchType] = useState<"email" | "cpf">("email")
  const [searchValue, setSearchValue] = useState("")
  const [tickets, setTickets] = useState<any[]>([])
  const [isSearching, setIsSearching] = useState(false)
  const [hasSearched, setHasSearched] = useState(false)
  const [selectedTicket, setSelectedTicket] = useState<any>(null)

  const handleSearch = async () => {
    if (!searchValue.trim()) return

    setIsSearching(true)
    setHasSearched(true)

    try {
      let results
      if (searchType === "email") {
        results = await getTicketsByEmail(searchValue)
      } else {
        results = await getTicketsByCPF(searchValue)
      }

      setTickets(results)
    } catch (error) {
      console.error("Error searching tickets:", error)
    } finally {
      setIsSearching(false)
    }
  }

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  const handleViewTicket = (ticket: any) => {
    setSelectedTicket(ticket)
  }

  const handleCloseTicket = () => {
    setSelectedTicket(null)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-purple-900 text-white p-6">
      <div className="max-w-4xl mx-auto">
        <motion.h1
          className="text-3xl font-bold text-center mb-2"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          Meus Ingressos
        </motion.h1>

        <motion.p
          className="text-gray-300 text-center mb-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          Consulte seus ingressos usando seu e-mail ou CPF
        </motion.p>

        <motion.div
          className="bg-purple-900/40 rounded-lg p-6 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <div className="flex gap-4 mb-4">
            <Button
              type="button"
              variant={searchType === "email" ? "default" : "outline"}
              className={searchType === "email" ? "bg-pink-500 hover:bg-pink-600" : ""}
              onClick={() => setSearchType("email")}
            >
              <Mail className="w-4 h-4 mr-2" />
              Buscar por E-mail
            </Button>

            <Button
              type="button"
              variant={searchType === "cpf" ? "default" : "outline"}
              className={searchType === "cpf" ? "bg-pink-500 hover:bg-pink-600" : ""}
              onClick={() => setSearchType("cpf")}
            >
              <User className="w-4 h-4 mr-2" />
              Buscar por CPF
            </Button>
          </div>

          <div className="flex gap-2">
            <div className="relative flex-1">
              <input
                type={searchType === "email" ? "email" : "text"}
                value={searchValue}
                onChange={(e) => setSearchValue(e.target.value)}
                placeholder={searchType === "email" ? "seu.email@exemplo.com" : "000.000.000-00"}
                className="w-full bg-purple-950 border border-purple-800 rounded-md p-3 text-white"
              />
            </div>

            <Button
              type="button"
              className="bg-gradient-to-r from-pink-500 to-pink-600"
              onClick={handleSearch}
              disabled={isSearching}
            >
              {isSearching ? (
                <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"></div>
              ) : (
                <>
                  <Search className="w-4 h-4 mr-2" />
                  Buscar
                </>
              )}
            </Button>
          </div>
        </motion.div>

        {hasSearched && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            {tickets.length > 0 ? (
              <div className="space-y-4">
                <h2 className="text-xl font-bold mb-4">Ingressos encontrados ({tickets.length})</h2>

                {tickets.map((ticket) => (
                  <motion.div
                    key={ticket.code}
                    className="bg-purple-900/40 rounded-lg p-4 flex items-center justify-between"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    whileHover={{ y: -2 }}
                  >
                    <div className="flex items-center">
                      <div
                        className={`w-10 h-10 rounded-full ${ticket.used ? "bg-gray-500/20" : "bg-green-500/20"} flex items-center justify-center mr-4`}
                      >
                        <Ticket className={`w-5 h-5 ${ticket.used ? "text-gray-400" : "text-green-400"}`} />
                      </div>

                      <div>
                        <h3 className="font-bold">{ticket.type}</h3>
                        <p className="text-sm text-gray-300">
                          {ticket.name} • {formatDate(ticket.timestamp)}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center">
                      {ticket.used && (
                        <span className="bg-gray-700 text-gray-300 text-xs px-2 py-1 rounded mr-3">Utilizado</span>
                      )}

                      <Button
                        size="sm"
                        onClick={() => handleViewTicket(ticket)}
                        className="bg-gradient-to-r from-pink-500 to-pink-600"
                      >
                        Ver Ingresso
                      </Button>
                    </div>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-300 mb-4">Nenhum ingresso encontrado para esta busca.</p>
                <Link href="/">
                  <Button className="bg-gradient-to-r from-pink-500 to-pink-600">Comprar Ingressos</Button>
                </Link>
              </div>
            )}
          </motion.div>
        )}
      </div>

      {/* Ticket Modal */}
      {selectedTicket && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <motion.div
            className="bg-purple-900 rounded-lg p-6 max-w-md w-full"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
          >
            <h2 className="text-xl font-bold text-center mb-4">Seu Ingresso</h2>

            <div className="bg-white p-6 rounded-lg mx-auto mb-6">
              <QRCode
                value={JSON.stringify({
                  code: selectedTicket.code,
                  type: selectedTicket.type,
                  name: selectedTicket.name,
                  email: selectedTicket.email,
                  timestamp: selectedTicket.timestamp,
                })}
                size={200}
                className="mx-auto"
              />
            </div>

            <div className="space-y-4 mb-6">
              <div className="bg-purple-800/50 p-3 rounded-lg">
                <p className="text-sm text-gray-300 mb-1">Nome:</p>
                <p className="font-bold">{selectedTicket.name}</p>
              </div>

              <div className="bg-purple-800/50 p-3 rounded-lg">
                <p className="text-sm text-gray-300 mb-1">Tipo de Ingresso:</p>
                <p className="font-bold">
                  {selectedTicket.type} - R$ {selectedTicket.price}
                </p>
              </div>

              <div className="bg-purple-800/50 p-3 rounded-lg">
                <p className="text-sm text-gray-300 mb-1">Código:</p>
                <p className="font-mono text-sm">{selectedTicket.code}</p>
              </div>

              <div className="bg-purple-800/50 p-3 rounded-lg">
                <p className="text-sm text-gray-300 mb-1">Status:</p>
                <p className={`font-medium ${selectedTicket.used ? "text-gray-400" : "text-green-400"}`}>
                  {selectedTicket.used ? "Ingresso já utilizado" : "Ingresso válido"}
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <Button variant="outline" className="flex-1" onClick={handleCloseTicket}>
                Fechar
              </Button>

              <Button className="flex-1 bg-gradient-to-r from-pink-500 to-pink-600" onClick={() => window.print()}>
                Imprimir
              </Button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  )
}
