"use client"

import Image from "next/image"
import { Calendar, Clock, MapPin, MessageSquare } from "lucide-react"
import Link from "next/link"
import { motion } from "framer-motion"
import { AnimatedIcon } from "@/components/animated-icon"
import { AnimatedCrown } from "@/components/animated-crown"
import { TicketCard } from "@/components/ticket-card"
import { useEffect, useState } from "react"
import { Header } from "@/components/header"

export default function Home() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-purple-900 text-white">
      {/* Header */}
      <Header />

      {/* Hero Section */}
      <section className="text-center py-12 px-4 relative">
        <div className="absolute inset-0 overflow-hidden">
          <Image src="/images/hero-bg.png" alt="Revoada do Gouveia" fill className="object-cover opacity-30" priority />
          <div className="absolute inset-0 bg-gradient-to-b from-purple-900/70 via-purple-900/50 to-purple-900/90"></div>
        </div>

        <div className="relative z-10">
          <motion.div
            className="flex justify-center mb-4"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 260, damping: 20 }}
          >
            <AnimatedCrown />
          </motion.div>

          <motion.h1
            className="text-5xl font-bold mb-2 bg-gradient-to-r from-pink-500 to-blue-500 bg-clip-text text-transparent"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            REVOADA DO
            <br />
            GOUVEIA
          </motion.h1>

          <motion.div
            className="w-16 h-1 bg-pink-500 mx-auto my-6"
            initial={{ width: 0 }}
            animate={{ width: 64 }}
            transition={{ delay: 0.4 }}
          ></motion.div>

          <motion.h2
            className="text-2xl font-bold mb-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            O MAIOR BAILE DA 019!
          </motion.h2>

          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <motion.div
              className="bg-purple-900/60 px-6 py-3 rounded-full flex items-center gap-2"
              initial={{ x: -50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.6 }}
              whileHover={{ y: -5 }}
            >
              <AnimatedIcon pulse>
                <Calendar className="w-5 h-5 text-pink-400" />
              </AnimatedIcon>
              <span>7 de Junho</span>
            </motion.div>

            <motion.div
              className="bg-purple-900/60 px-6 py-3 rounded-full flex items-center gap-2"
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.7 }}
              whileHover={{ y: -5 }}
            >
              <AnimatedIcon pulse>
                <Clock className="w-5 h-5 text-pink-400" />
              </AnimatedIcon>
              <span>A partir das 22h</span>
            </motion.div>

            <motion.div
              className="bg-purple-900/60 px-6 py-3 rounded-full flex items-center gap-2"
              initial={{ x: 50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.8 }}
              whileHover={{ y: -5 }}
            >
              <AnimatedIcon pulse>
                <MapPin className="w-5 h-5 text-pink-400" />
              </AnimatedIcon>
              <span>Chácara Frezzarin</span>
            </motion.div>
          </div>

          <motion.a
            href="https://chat.whatsapp.com/CCSOuqq4ef741SpU0eaZgD"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-gradient-to-r from-pink-500 to-pink-600 px-8 py-3 rounded-full font-medium flex items-center gap-2 mx-auto inline-flex"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.9 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <AnimatedIcon pulse>
              <MessageSquare className="w-5 h-5" />
            </AnimatedIcon>
            GRUPO DO WHATSAPP
          </motion.a>
        </div>
      </section>

      {/* Tickets Section */}
      <section className="py-12 px-4" id="ingressos">
        <motion.h2
          className="text-2xl font-bold text-center mb-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          Garanta seu ingresso
        </motion.h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-5xl mx-auto">
          <TicketCard
            icon={
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M12 12C14.7614 12 17 9.76142 17 7C17 4.23858 14.7614 2 12 2C9.23858 2 7 4.23858 7 7C7 9.76142 9.23858 12 12 12Z"
                  fill="#EC4899"
                />
                <path d="M12 14C7.58172 14 4 17.5817 4 22H20C20 17.5817 16.4183 14 12 14Z" fill="#EC4899" />
              </svg>
            }
            title="Ingresso Feminino"
            description="Acesso à pista principal"
            price="25"
            color="border-pink-500"
            buttonColor="bg-gradient-to-r from-pink-500 to-pink-600"
            iconBgColor="bg-pink-500/20"
          />

          <TicketCard
            icon={
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M12 12C14.7614 12 17 9.76142 17 7C17 4.23858 14.7614 2 12 2C9.23858 2 7 4.23858 7 7C7 9.76142 9.23858 12 12 12Z"
                  fill="#3B82F6"
                />
                <path d="M12 14C7.58172 14 4 17.5817 4 22H20C20 17.5817 16.4183 14 12 14Z" fill="#3B82F6" />
              </svg>
            }
            title="Ingresso Masculino"
            description="Acesso à pista principal"
            price="40"
            color="border-blue-500"
            buttonColor="bg-gradient-to-r from-blue-500 to-blue-600"
            iconBgColor="bg-blue-500/20"
          />

          <TicketCard
            icon={
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                  fill="#EAB308"
                />
              </svg>
            }
            title="Ingresso VIP"
            description="Acesso à área VIP + Open Bar 1h"
            price="65"
            color="border-yellow-500"
            buttonColor="bg-gradient-to-r from-yellow-500 to-yellow-600"
            iconBgColor="bg-yellow-500/20"
          />
        </div>
      </section>

      {/* Meus Ingressos Section */}
      <section className="py-12 px-4 bg-purple-900/30">
        <div className="max-w-5xl mx-auto text-center">
          <motion.h2 className="text-2xl font-bold mb-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            Já comprou seu ingresso?
          </motion.h2>

          <motion.p
            className="text-gray-300 mb-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1 }}
          >
            Acesse seus ingressos ou verifique o status da sua compra
          </motion.p>

          <Link href="/meus-ingressos">
            <motion.button
              className="bg-gradient-to-r from-pink-500 to-pink-600 px-8 py-3 rounded-full font-medium"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              MEUS INGRESSOS
            </motion.button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-purple-800">
        <div className="max-w-5xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <div className="text-pink-500 font-bold">REVOADA DO GOUVEIA 6.0</div>
            <div className="flex gap-4">
              <Link href="#" className="text-white hover:text-pink-400">
                Instagram
              </Link>
              <Link href="#" className="text-white hover:text-pink-400">
                WhatsApp
              </Link>
              <Link href="#" className="text-white hover:text-pink-400">
                TikTok
              </Link>
            </div>
          </div>
          <p className="text-sm text-gray-400 text-center">© 2025 Revoada do Gouveia. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  )
}
