"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { Copy, Check, Clock, AlertTriangle, Upload, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { getPaymentIntent, confirmPayment } from "@/lib/payment-service"
import Link from "next/link"
import { createTicket } from "@/lib/ticket-service"
import { generateTicketCode } from "@/lib/qr-generator"
import QRCode from "react-qr-code"

export default function PaymentPage() {
  const params = useParams()
  const router = useRouter()
  const paymentId = params.id as string

  const [payment, setPayment] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [copied, setCopied] = useState(false)
  const [confirming, setConfirming] = useState(false)
  const [timeLeft, setTimeLeft] = useState("")

  // Estado para o comprovante de pagamento
  const [paymentProof, setPaymentProof] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)

  useEffect(() => {
    async function fetchPayment() {
      if (!paymentId) return

      try {
        const paymentData = await getPaymentIntent(paymentId)
        setPayment(paymentData)
      } catch (error) {
        console.error("Error fetching payment:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchPayment()
  }, [paymentId])

  useEffect(() => {
    if (!payment) return

    // Update countdown timer
    const interval = setInterval(() => {
      const now = Date.now()
      const expiresAt = payment.expiresAt
      const diff = expiresAt - now

      if (diff <= 0) {
        setTimeLeft("Expirado")
        clearInterval(interval)
        return
      }

      const hours = Math.floor(diff / (1000 * 60 * 60))
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
      const seconds = Math.floor((diff % (1000 * 60)) / 1000)

      setTimeLeft(
        `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`,
      )
    }, 1000)

    return () => clearInterval(interval)
  }, [payment])

  const handleCopy = () => {
    if (!payment || !payment.pixCode) return

    navigator.clipboard.writeText(payment.pixCode)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      setPaymentProof(file)

      // Create preview URL
      const reader = new FileReader()
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleConfirmPayment = async () => {
    if (!payment || !paymentProof) return

    setConfirming(true)

    try {
      // Confirm payment
      const updatedPayment = await confirmPayment(paymentId)

      if (updatedPayment && updatedPayment.status === "paid") {
        // Generate ticket code
        const ticketCode = generateTicketCode(updatedPayment.ticketInfo.type, updatedPayment.customerInfo.email)

        // Create ticket in database
        await createTicket({
          code: ticketCode,
          type: updatedPayment.ticketInfo.type,
          price: updatedPayment.amount,
          name: updatedPayment.customerInfo.name,
          email: updatedPayment.customerInfo.email,
          cpf: updatedPayment.customerInfo.cpf,
          timestamp: Date.now(),
          used: false,
        })

        // Redirect to payment confirmation page
        router.push(`/payment-confirmation?ticketId=${ticketCode}`)
      } else {
        alert("Não foi possível confirmar o pagamento. Por favor, tente novamente.")
        setConfirming(false)
      }
    } catch (error) {
      console.error("Error confirming payment:", error)
      setConfirming(false)
      alert("Ocorreu um erro ao confirmar o pagamento. Por favor, tente novamente.")
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-purple-900 text-white flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-4 border-pink-500 border-t-transparent rounded-full"></div>
      </div>
    )
  }

  if (!payment) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-purple-900 text-white p-6">
        <div className="max-w-md mx-auto bg-purple-900/40 rounded-lg p-6 text-center">
          <h1 className="text-2xl font-bold mb-4">Pagamento não encontrado</h1>
          <p className="text-gray-300 mb-6">O pagamento solicitado não foi encontrado ou já expirou.</p>
          <Link href="/">
            <Button className="bg-gradient-to-r from-pink-500 to-pink-600">Voltar para a página inicial</Button>
          </Link>
        </div>
      </div>
    )
  }

  // If payment is already paid, redirect to confirmation
  if (payment.status === "paid") {
    router.push(`/payment-confirmation?paymentId=${paymentId}`)
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-purple-900 text-white p-6">
      <div className="max-w-md mx-auto">
        <motion.div
          className="bg-purple-900/40 rounded-lg p-6 mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-yellow-500/20 rounded-full flex items-center justify-center">
              <Clock className="w-8 h-8 text-yellow-400" />
            </div>
          </div>

          <h1 className="text-2xl font-bold text-center mb-2">Pagamento Pendente</h1>
          <p className="text-gray-300 text-center mb-6">
            Utilize o código PIX abaixo para efetuar o pagamento e garantir seu ingresso.
          </p>

          <div className="bg-purple-800/50 p-4 rounded-lg mb-6">
            <div className="flex justify-between items-center mb-2">
              <p className="text-sm text-gray-300">Tempo restante:</p>
              <div className="flex items-center">
                <Clock className="w-4 h-4 mr-1 text-yellow-400" />
                <span className="font-mono">{timeLeft}</span>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <p className="text-sm text-gray-300">Status:</p>
              <span className="bg-yellow-500/20 text-yellow-400 text-xs px-2 py-1 rounded">Aguardando Pagamento</span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg mx-auto mb-6">
            {payment.pixCode ? (
              <QRCode value={payment.pixCode} size={200} className="mx-auto" />
            ) : (
              <div className="text-black text-center py-10">
                Erro ao gerar QR Code. Por favor, use o código PIX abaixo.
              </div>
            )}
          </div>

          <div className="bg-purple-800/30 p-4 rounded-lg mb-6">
            <h2 className="font-bold mb-4">Instruções de Pagamento</h2>

            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-300 mb-1">1. Código PIX:</p>
                <div className="bg-purple-950 p-3 rounded-md flex justify-between items-center">
                  <span className="font-mono text-xs overflow-hidden overflow-ellipsis whitespace-normal break-all">
                    {payment.pixCode || "Código PIX não disponível"}
                  </span>
                  <Button variant="ghost" size="icon" onClick={handleCopy} className="h-8 w-8 ml-2 flex-shrink-0">
                    {copied ? <Check className="h-4 w-4 text-green-400" /> : <Copy className="h-4 w-4" />}
                  </Button>
                </div>
              </div>

              <div>
                <p className="text-sm text-gray-300 mb-1">2. Valor:</p>
                <p className="font-bold text-xl">R$ {payment.amount}</p>
              </div>

              <div className="border-t border-purple-700 pt-4">
                <p className="text-sm mb-2">
                  <span className="font-medium">Como pagar:</span>
                </p>
                <ol className="text-sm text-gray-300 space-y-2 list-decimal list-inside">
                  <li>Abra o aplicativo do seu banco</li>
                  <li>Selecione a opção "Pagar com PIX"</li>
                  <li>Escaneie o QR Code acima ou copie e cole o código PIX</li>
                  <li>Confirme o valor de R$ {payment.amount}</li>
                  <li>Finalize o pagamento</li>
                  <li>Após o pagamento, envie o comprovante abaixo</li>
                </ol>
              </div>
            </div>
          </div>

          {/* Seção de upload do comprovante */}
          <div className="bg-purple-800/30 p-4 rounded-lg mb-6">
            <h2 className="font-bold mb-4">Envie seu Comprovante de Pagamento</h2>
            <p className="text-sm text-gray-300 mb-4">
              Para confirmar seu pagamento, envie uma foto ou screenshot do comprovante de pagamento.
            </p>

            <div className="border-2 border-dashed border-purple-700 rounded-lg p-4 text-center mb-4">
              {previewUrl ? (
                <div className="relative">
                  <img src={previewUrl || "/placeholder.svg"} alt="Comprovante" className="max-h-48 mx-auto rounded" />
                  <button
                    type="button"
                    onClick={() => {
                      setPaymentProof(null)
                      setPreviewUrl(null)
                    }}
                    className="absolute top-2 right-2 bg-red-500 rounded-full p-1"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <label className="cursor-pointer block py-8">
                  <Upload className="w-10 h-10 mx-auto mb-2 text-gray-400" />
                  <p className="text-gray-300">Clique para enviar o comprovante</p>
                  <p className="text-xs text-gray-400 mt-1">Formatos aceitos: JPG, PNG, PDF</p>
                  <input type="file" accept="image/*,.pdf" onChange={handleFileChange} className="hidden" />
                </label>
              )}
            </div>

            {!paymentProof && (
              <div className="bg-red-900/30 p-3 rounded-md flex items-start mb-4">
                <AlertTriangle className="w-5 h-5 text-red-400 mr-2 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-gray-300">
                  <span className="font-medium text-red-400">Atenção:</span> É necessário enviar o comprovante de
                  pagamento para poder confirmar e gerar seu ingresso.
                </p>
              </div>
            )}
          </div>

          <div className="bg-yellow-500/10 border border-yellow-500/30 p-3 rounded-md flex items-start mb-6">
            <AlertTriangle className="w-5 h-5 text-yellow-400 mr-2 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-gray-300">
              <span className="font-medium text-yellow-400">Importante:</span> Após enviar o comprovante, clique em
              "Confirmar Pagamento" para gerar seu ingresso.
            </p>
          </div>

          <div className="flex gap-3">
            <Button variant="outline" className="flex-1" onClick={() => router.push("/")}>
              Cancelar
            </Button>
            <Button
              className="flex-1 bg-gradient-to-r from-pink-500 to-pink-600"
              onClick={handleConfirmPayment}
              disabled={confirming || !paymentProof}
            >
              {confirming ? (
                <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"></div>
              ) : (
                "Confirmar Pagamento"
              )}
            </Button>
          </div>
        </motion.div>

        <div className="text-center">
          <p className="text-sm text-gray-400 mb-2">Dúvidas sobre o pagamento?</p>
          <Link href="https://wa.me/5519994027338" target="_blank" className="text-pink-400 text-sm">
            Entre em contato com o suporte
          </Link>
        </div>
      </div>
    </div>
  )
}
