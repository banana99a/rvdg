"use client"

import { useEffect, useState } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { Check, Download, Mail, Share2 } from "lucide-react"
import QRCode from "react-qr-code"
import { Button } from "@/components/ui/button"
import { getTicketByCode, sendTicketByEmail } from "@/lib/ticket-service"
import { getPaymentIntent } from "@/lib/payment-service"
import Link from "next/link"

export default function PaymentConfirmation() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const ticketId = searchParams.get("ticketId")
  const paymentId = searchParams.get("paymentId")

  const [ticket, setTicket] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [emailSent, setEmailSent] = useState(false)
  const [sendingEmail, setSendingEmail] = useState(false)

  useEffect(() => {
    async function fetchData() {
      try {
        if (ticketId) {
          // Fetch ticket directly
          const ticketData = await getTicketByCode(ticketId)
          setTicket(ticketData)

          // Automatically send email on page load
          if (ticketData) {
            sendEmail(ticketData.email, ticketData.code, ticketData.name, ticketData.type)
          }
        } else if (paymentId) {
          // Fetch payment and then ticket
          const paymentData = await getPaymentIntent(paymentId)

          if (paymentData && paymentData.status === "paid") {
            // Find ticket associated with this payment
            const ticketData = await getTicketByCode(paymentData.ticketCode || "")

            if (ticketData) {
              setTicket(ticketData)
              // Automatically send email on page load
              sendEmail(ticketData.email, ticketData.code, ticketData.name, ticketData.type)
            } else {
              // Redirect to home if no ticket found
              router.push("/")
            }
          } else {
            // Redirect to payment page if payment not paid
            if (paymentData) {
              router.push(`/payment/${paymentId}`)
            } else {
              router.push("/")
            }
          }
        } else {
          // No ticket or payment ID provided
          router.push("/")
        }
      } catch (error) {
        console.error("Error fetching data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [ticketId, paymentId, router])

  const sendEmail = async (email: string, code: string, name: string, type: string) => {
    setSendingEmail(true)
    try {
      await sendTicketByEmail(email, code, name, type)
      setEmailSent(true)
    } catch (error) {
      console.error("Error sending email:", error)
    } finally {
      setSendingEmail(false)
    }
  }

  const handleResendEmail = async () => {
    if (!ticket) return
    await sendEmail(ticket.email, ticket.code, ticket.name, ticket.type)
  }

  const handleDownloadQR = () => {
    if (!ticket) return

    const canvas = document.getElementById("ticket-qr") as HTMLCanvasElement
    if (!canvas) return

    const pngUrl = canvas.toDataURL("image/png").replace("image/png", "image/octet-stream")
    const downloadLink = document.createElement("a")
    downloadLink.href = pngUrl
    downloadLink.download = `ingresso-${ticket.code}.png`
    document.body.appendChild(downloadLink)
    downloadLink.click()
    document.body.removeChild(downloadLink)
  }

  const handleShareTicket = () => {
    if (!ticket) return

    if (navigator.share) {
      navigator
        .share({
          title: `Ingresso Revoada do Gouveia - ${ticket.type}`,
          text: `Meu ingresso para a Revoada do Gouveia: ${ticket.type}`,
          url: window.location.href,
        })
        .catch((error) => console.log("Error sharing", error))
    } else {
      // Fallback for browsers that don't support Web Share API
      const shareText = `Meu ingresso para a Revoada do Gouveia: ${ticket.type} - ${window.location.href}`
      navigator.clipboard.writeText(shareText)
      alert("Link copiado para a área de transferência!")
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-purple-900 text-white flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-4 border-pink-500 border-t-transparent rounded-full"></div>
      </div>
    )
  }

  if (!ticket) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-purple-900 text-white p-6">
        <div className="max-w-md mx-auto bg-purple-900/40 rounded-lg p-6 text-center">
          <h1 className="text-2xl font-bold mb-4">Ingresso não encontrado</h1>
          <p className="text-gray-300 mb-6">O ingresso solicitado não foi encontrado ou já expirou.</p>
          <Link href="/">
            <Button className="bg-gradient-to-r from-pink-500 to-pink-600">Voltar para a página inicial</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-purple-900 text-white p-6">
      <div className="max-w-md mx-auto">
        <motion.div
          className="bg-purple-900/40 rounded-lg p-6 mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center">
              <Check className="w-8 h-8 text-green-400" />
            </div>
          </div>

          <h1 className="text-2xl font-bold text-center mb-2">Pagamento Confirmado!</h1>
          <p className="text-gray-300 text-center mb-6">
            Seu ingresso foi gerado com sucesso e enviado para seu e-mail.
          </p>

          <div className="bg-white p-6 rounded-lg mx-auto mb-6">
            <QRCode
              id="ticket-qr"
              value={JSON.stringify({
                code: ticket.code,
                type: ticket.type,
                name: ticket.name,
                email: ticket.email,
                timestamp: ticket.timestamp,
              })}
              size={200}
              className="mx-auto"
            />
          </div>

          <div className="space-y-4">
            <div className="bg-purple-800/50 p-3 rounded-lg">
              <p className="text-sm text-gray-300 mb-1">Nome:</p>
              <p className="font-bold">{ticket.name}</p>
            </div>

            <div className="bg-purple-800/50 p-3 rounded-lg">
              <p className="text-sm text-gray-300 mb-1">Tipo de Ingresso:</p>
              <p className="font-bold">
                {ticket.type} - R$ {ticket.price}
              </p>
            </div>

            <div className="bg-purple-800/50 p-3 rounded-lg">
              <p className="text-sm text-gray-300 mb-1">Código:</p>
              <p className="font-mono text-sm">{ticket.code}</p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Button onClick={handleDownloadQR} variant="outline" className="flex items-center justify-center gap-2">
                <Download className="w-4 h-4" />
                Baixar QR Code
              </Button>

              <Button
                onClick={handleResendEmail}
                disabled={sendingEmail}
                className="bg-gradient-to-r from-pink-500 to-pink-600 flex items-center justify-center gap-2"
              >
                {sendingEmail ? (
                  <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                ) : (
                  <>
                    <Mail className="w-4 h-4" />
                    {emailSent ? "Reenviar E-mail" : "Enviar E-mail"}
                  </>
                )}
              </Button>

              <Button
                onClick={handleShareTicket}
                variant="outline"
                className="col-span-2 flex items-center justify-center gap-2"
              >
                <Share2 className="w-4 h-4" />
                Compartilhar Ingresso
              </Button>
            </div>
          </div>

          <div className="mt-6 text-center text-sm text-gray-300">
            <p>Uma cópia deste ingresso também foi enviada para o organizador do evento.</p>
            <p>Em caso de dúvidas, entre em contato pelo WhatsApp (19) 99402-7338.</p>
          </div>
        </motion.div>

        <div className="text-center">
          <Link href="/meus-ingressos">
            <Button variant="link" className="text-pink-400">
              Ver todos os meus ingressos
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
