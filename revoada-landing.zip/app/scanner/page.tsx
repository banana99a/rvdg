"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { QrCode, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { QrScanner } from "@/components/qr-scanner"
import { TicketVerificationResult } from "@/components/ticket-verification-result"
import { validateTicket } from "@/lib/qr-generator"
import Link from "next/link"
import { DebugQrScanner } from "@/components/debug-qr-scanner"

export default function ScannerPage() {
  const [showScanner, setShowScanner] = useState(false)
  const [scanResult, setScanResult] = useState<string | null>(null)
  const [verificationResult, setVerificationResult] = useState<any>(null)
  const [isVerifying, setIsVerifying] = useState(false)

  const handleScanSuccess = async (decodedText: string) => {
    setScanResult(decodedText)
    setShowScanner(false)

    setIsVerifying(true)
    try {
      const result = await validateTicket(decodedText)
      setVerificationResult(result)
    } catch (error) {
      console.error("Error validating ticket:", error)
      setVerificationResult({
        valid: false,
        message: "Erro ao validar o QR code.",
      })
    } finally {
      setIsVerifying(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-purple-900 text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/">
            <Button variant="ghost" size="icon" className="mr-2">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Scanner de Ingressos</h1>
        </div>

        <div className="max-w-md mx-auto bg-purple-900/40 rounded-lg p-6">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 rounded-full bg-pink-500/20 flex items-center justify-center">
              <QrCode className="w-8 h-8 text-pink-400" />
            </div>
          </div>

          <h2 className="text-xl font-bold text-center mb-4">Validação de Ingressos</h2>
          <p className="text-gray-300 text-center mb-6">
            Escaneie o QR code do ingresso para validar a entrada do participante.
          </p>

          {!scanResult ? (
            <Button
              className="w-full bg-gradient-to-r from-pink-500 to-pink-600 py-3"
              onClick={() => setShowScanner(true)}
            >
              Escanear QR Code
            </Button>
          ) : (
            <div className="space-y-4">
              {isVerifying ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin h-8 w-8 border-4 border-pink-500 border-t-transparent rounded-full"></div>
                </div>
              ) : verificationResult ? (
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                  <TicketVerificationResult
                    isValid={verificationResult.valid}
                    message={verificationResult.message}
                    ticketInfo={verificationResult.ticketInfo}
                  />

                  <Button
                    className="w-full mt-4 bg-gradient-to-r from-pink-500 to-pink-600"
                    onClick={() => {
                      setScanResult(null)
                      setVerificationResult(null)
                    }}
                  >
                    Escanear Outro Ingresso
                  </Button>
                </motion.div>
              ) : null}
            </div>
          )}
        </div>
      </div>

      {showScanner && <QrScanner onScanSuccess={handleScanSuccess} onClose={() => setShowScanner(false)} />}

      <DebugQrScanner />
    </div>
  )
}
